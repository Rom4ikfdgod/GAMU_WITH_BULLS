#include "widget.h"
#include "ui_widget.h"
#include <QPainter>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    for (int i=0;i<NUMBER;i++)
        balls[i]=new BALL(width(),height());
    connect(&timer, SIGNAL(timeout()), this, SLOT(moveAll()));
    timer.start(20);
}

Widget::~Widget()
{
    for(int i=0;i<NUMBER;i++)
        delete balls[i];
    delete ui;
}
void Widget::paintEvent(QPaintEvent *e){
    QPainter painter(this);
    for(int i=0; i<NUMBER;i++)
        balls[i]->draw(painter);

}
void Widget::moveAll()
{
    for (int i=0; i<NUMBER; i++)
        balls[i]->move(width(), height());
    this->repaint();
}

