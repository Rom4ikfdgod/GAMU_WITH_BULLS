#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include <QPaintEvent>
#include "ball.h"

namespace Ui {
class Widget;
}
const int NUMBER = 10;

class Widget : public QWidget
{
    Q_OBJECT
    QTimer timer;
    BALL *balls[NUMBER];

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
protected:
    void paintEvent(QPaintEvent *e);
protected slots:
    void moveAll();
    void GotTuched();
private:
    Ui::Widget *ui;


};

#endif // WIDGET_H
