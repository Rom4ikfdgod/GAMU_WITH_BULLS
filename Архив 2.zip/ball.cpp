#include "ball.h"

BALL::BALL(int w, int h)
{
    //делаем координаты
    r = 15 + rand ()%15;
    //устанавливаем координаты
    point.setX(r+rand()%(w-2*r) );
    point.setY(r+rand()%(h-2*r) );
    //придумываем цевт
    color = QColor::fromRgb(rand()%255,rand()%255,rand()%255);
    //устанавливаем скорости
    vx= rand()%5;
    vy= rand()%5;
    if (rand()%2==0) vx*=-1;
    if (rand()%2==0) vy*=-1;
}
void BALL::move(int w,int h){
    point +=QPoint(vx,vy);
    if (point.x() + r>=w )
        vx = -vx;
    if (point.x() - r<=0)
        vx = -vx;
    if (point.y() + r>+h)
        vy = -vy;
    if (point.y() - r<=0)
        vy = -vy;
}
void BALL::draw(QPainter &painter){
    painter.setBrush(QBrush(color,Qt::Dense1Pattern));
    painter.drawEllipse(point,r,r);
}
