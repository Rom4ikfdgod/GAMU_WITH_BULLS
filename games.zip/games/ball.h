#ifndef BALL_H
#define BALL_H
#include <QtGui>
#include <QPainter>

class BALL
{ 
protected:
    int vx, vy;
    int r;
    int x,y;
    int x_ball,y_ball;
    QColor color;
    QPoint point;
public:
    BALL(int w, int h);
    void move(int w,int h);
    void draw(QPainter& painter);

};

#endif // BALL_H
