#ifndef PULEIRU_H
#define PULEIRU_H
#include <QtGui>
#include <QPainter>
#include "ball.h"


class PULEIRU:public BALL
{
    int key_pressed;\
public:
    PULEIRU(int w, int h);\
    void move(int w,int h,int key_pressed);
    void draw(QPainter &painter);
};

#endif // PULEIRU_H
