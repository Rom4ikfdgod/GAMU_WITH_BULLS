#include "puleiru.h"

PULEIRU::PULEIRU(int w, int h) : BALL(w, h)
{
    //делаем координаты
    r = 15;
    //устанавливаем координаты
    point.setX(r+rand()%(w-2*r) );
    point.setY(r+rand()%(h-2*r) );
    //придумыxваем цвет
    color = QColor::fromRgb(0,0,0);
    //устанавливаем скорости
    vx= 11;
    vy= 11;
}
void PULEIRU::move(int w, int h, int key){
    if (key == Qt::Key_W){
        point -=QPoint(0,vy);
    }
    if (key == Qt::Key_A){
        point -= QPoint(vx,0);
    }
    if (key == Qt::Key_S){
        point +=QPoint(0,vy);
    }
    if (key == Qt::Key_D){
        point +=QPoint(vx,0);
    }
}
void PULEIRU::draw(QPainter& painter){
    painter.setBrush(QBrush(color,Qt::Dense7Pattern));
    painter.drawRect(point.x()-r,point.y()-r,2*r, 2*r);
}
