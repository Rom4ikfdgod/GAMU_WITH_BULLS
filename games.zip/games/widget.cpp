#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QDebug>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    for (int i=0;i<NUMBER;i++)
        balls[i]=new BALL(width(),height());
    connect(&timer, SIGNAL(timeout()), this, SLOT(moveAll()));
    timer.start(20);
    player=new PULEIRU(width(),height());
}


Widget::~Widget()
{
    for(int i=0;i<NUMBER;i++)
        delete balls[i];
    delete ui;
}
void Widget::paintEvent(QPaintEvent *e){
    QPainter painter(this);
    for(int i=0; i<NUMBER;i++)
        balls[i]->draw(painter);
    player->draw(painter);

}

void Widget::keyPressEvent(QKeyEvent *event)
{
    player->move(width(),height(),event->key());
    //qDebug()<<event->key();
    if(event->key()==Qt::Key_W){
        qDebug()<<"GO FUCKING UP";
    }
    if(event->key()==Qt::Key_A){
        qDebug()<<"GO FUCKING LEFT";
    }
    if(event->key()==Qt::Key_D){
        qDebug()<<"GO FUCKING RIGHT";
    }
    if(event->key()==Qt::Key_S){
        qDebug()<<"GO FUCKING DOWN";
    }
}
void Widget::moveAll()
{
    for (int i=0; i<NUMBER; i++)
        balls[i]->move(width(), height());
    this->repaint();
}

