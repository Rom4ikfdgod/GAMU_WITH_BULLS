#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include <QPaintEvent>
#include <QKeyEvent>
#include "ball.h"
#include "puleiru.h"

namespace Ui {
class Widget;
}
const int NUMBER = 10;

class Widget : public QWidget
{
    Q_OBJECT
    QTimer timer;
    BALL *balls[NUMBER];
    PULEIRU *player;

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
protected:
    void paintEvent(QPaintEvent *e);
    void keyPressEvent(QKeyEvent *event);
protected slots:
    void moveAll();
    //void GotTouched();
private:
    Ui::Widget *ui;


};

#endif // WIDGET_H
